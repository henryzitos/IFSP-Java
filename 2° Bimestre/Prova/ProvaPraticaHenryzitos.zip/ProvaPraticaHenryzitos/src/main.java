import java.util.*;
import model.ItemPedido;
import model.Orcamento;
import model.Pedido;
import repository.ExibirInterface;

public class main {
    ItemPedido Item = new ItemPedido("Moletom", "Casaco", "M", 100.99);
    //Completo
    //Reduzido

    Orcamento orcamento = new Orcamento();
    //Completo
    //Reduzido
}
