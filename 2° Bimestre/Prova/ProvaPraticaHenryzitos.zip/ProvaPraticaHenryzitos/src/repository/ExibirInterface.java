package repository;

public interface ExibirInterface {
    public void exibir(Boolean cr);
}
